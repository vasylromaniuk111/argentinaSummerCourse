package com.solvd.insurance.exceptions;

public class AgeException extends Exception{
    public AgeException(String message) { super(message);}

}
