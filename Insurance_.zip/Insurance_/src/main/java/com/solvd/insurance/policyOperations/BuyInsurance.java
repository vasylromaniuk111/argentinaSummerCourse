package com.solvd.insurance.policyOperations;

public class BuyInsurance {
}
