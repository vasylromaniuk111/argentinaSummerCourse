//package com.solvd.insurance.DAO.mysql;
//
//public interface IEmployeesDAO extends IBaseDAO<Employees>{
//}
