package com.solvd.insurance.interfaces;

public interface ICancelPolicy {
    void CancelPolicy();
}
