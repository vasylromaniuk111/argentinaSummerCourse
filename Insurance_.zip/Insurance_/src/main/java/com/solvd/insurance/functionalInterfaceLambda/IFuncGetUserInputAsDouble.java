package com.solvd.insurance.functionalInterfaceLambda;

public interface IFuncGetUserInputAsDouble {

  double getInput(String s);

}
