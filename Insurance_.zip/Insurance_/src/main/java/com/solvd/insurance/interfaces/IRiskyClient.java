package com.solvd.insurance.interfaces;

public interface IRiskyClient {
    public boolean isRisky();
    public void description();
}
