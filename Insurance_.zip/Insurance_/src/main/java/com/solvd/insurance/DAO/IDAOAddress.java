package com.solvd.insurance.DAO;

public interface IDAOAddress {
}
