package com.solvd.insurance.exceptions;

public class InvalidUserInputException extends Exception{
    public InvalidUserInputException(String message) { super(message);}

}
