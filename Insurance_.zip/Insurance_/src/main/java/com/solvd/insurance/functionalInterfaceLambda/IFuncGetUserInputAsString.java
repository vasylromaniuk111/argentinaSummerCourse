package com.solvd.insurance.functionalInterfaceLambda;

public interface IFuncGetUserInputAsString {
  
  String getInput(String s);
}
