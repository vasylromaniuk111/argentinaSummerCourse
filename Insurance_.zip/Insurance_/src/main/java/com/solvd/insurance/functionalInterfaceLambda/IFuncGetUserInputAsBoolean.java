package com.solvd.insurance.functionalInterfaceLambda;

public interface IFuncGetUserInputAsBoolean {

  boolean getInput(String s);

}
