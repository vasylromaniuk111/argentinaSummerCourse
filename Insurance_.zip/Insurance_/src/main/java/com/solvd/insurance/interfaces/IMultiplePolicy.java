package com.solvd.insurance.interfaces;

public interface IMultiplePolicy {
    void MultiplePolicy();
}
