package com.solvd.insurance.enums;

public enum InsuranceCompany {
  GEICO,
  FARMERS,
  TRIPLEA
}
