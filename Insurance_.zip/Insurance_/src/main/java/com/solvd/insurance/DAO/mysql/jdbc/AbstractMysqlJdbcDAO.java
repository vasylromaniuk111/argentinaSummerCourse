package com.solvd.insurance.DAO.mysql.jdbc;

public class AbstractMysqlJdbcDAO {
}
