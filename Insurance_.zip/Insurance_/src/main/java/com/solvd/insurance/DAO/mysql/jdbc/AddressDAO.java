package com.solvd.insurance.DAO.mysql.jdbc;

import com.solvd.insurance.DAO.IDAOAddress;

public class AddressDAO extends AbstractMysqlJdbcDAO implements IDAOAddress {
}
