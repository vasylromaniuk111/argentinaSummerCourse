package com.solvd.insurance.exceptions;

public class NoSuchInsuranceCompanyException extends Exception{
    public NoSuchInsuranceCompanyException(String message) { super(message);}

}
