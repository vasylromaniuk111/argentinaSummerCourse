package com.solvd.insurance.interfaces;

public interface IDisplayAge {
    void DisplayAge();
}
