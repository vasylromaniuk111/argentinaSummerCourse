package com.solvd.insurance.exceptions;

public class WrongPaymentMethodException extends Exception{
    public WrongPaymentMethodException(String message) { super(message);}
}
